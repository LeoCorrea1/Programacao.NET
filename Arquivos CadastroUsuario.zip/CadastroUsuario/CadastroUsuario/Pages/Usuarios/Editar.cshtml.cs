using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CadastroUsuario.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CadastroUsuario.Pages.Usuarios
{
    public class EditarModel : PageModel
    {
        [BindProperty]
        public Usuario Usuario { get; set; }
        public void OnGet(int id)
        {
            var usuarios = CarregarUsuarios();
            Usuario = usuarios.FirstOrDefault(u => u.Id == id); // Carrega dados atuais no formulário [cite: 892]
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page(); // Validação falhou [cite: 905]
            }

            // Lê todas as linhas do arquivo e converte para Lista manipulável [cite: 909]
            var linhas = System.IO.File.ReadAllLines("usuarios.txt").ToList();

            for (int i = 0; i < linhas.Count; i++)
            {
                var dados = linhas[i].Split(';');
                // Se encontrar a linha com o ID correspondente [cite: 918]
                if (int.Parse(dados[0]) == Usuario.Id)
                {
                    // Substitui a linha com os novos dados digitados [cite: 923]
                    linhas[i] = Usuario.Id + ";" + Usuario.Nome + ";" + Usuario.Senha + ";" + Usuario.Email;
                    break;
                }
            }

            // Sobrescreve o arquivo texto inteiro com a lista de linhas atualizada [cite: 931]
            System.IO.File.WriteAllLines("usuarios.txt", contents: linhas);

            return RedirectToPage("/Usuarios/Index"); // Retorna à lista [cite: 932]
        }

        private List<Usuario> CarregarUsuarios()
        {
            var lista = new List<Usuario>();
            if (System.IO.File.Exists("usuarios.txt"))
            {
                var linhas = System.IO.File.ReadAllLines("usuarios.txt");
                foreach (var linha in linhas)
                {
                    var dados = linha.Split(';');
                    lista.Add(new Usuario
                    {
                        Id = int.Parse(dados[0]),
                        Nome = dados[1],
                        Senha = dados[2],
                        Email = dados[3]
                    });
                }
            }
            return lista;
        }

    }
      

}
