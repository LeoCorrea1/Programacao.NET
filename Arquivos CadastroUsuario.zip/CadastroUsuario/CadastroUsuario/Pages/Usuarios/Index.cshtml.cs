using CadastroUsuario.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.IO;

namespace CadastroUsuario.Pages.Usuarios
{
    public class IndexModel : PageModel
    {
        public List<Usuario> Usuarios { get; set; } 

        public void OnGet() 
        {
            Usuarios = new List<Usuario>(); 

            if (System.IO.File.Exists("usuarios.txt")) // Verifica se o arquivo existe 
            {
                var linhas = System.IO.File.ReadAllLines("usuarios.txt"); // Lê tudo 
                foreach (var linha in linhas) 
                {
                    var dados = linha.Split(';'); // Divide pelos delimitadores 
       
                var usuario = new Usuario()
                    {
                        Id = int.Parse(dados[0]), 
                        Nome = dados[1],          
                        Senha = dados[2],       
                        Email = dados[3]          
                    };
                    Usuarios.Add(usuario); // Adiciona na coleção 
                }
            }
        }
    }
    
}
