using CadastroLivro.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.IO;

namespace CadastroUsuario.Pages.Livros
{
    public class IndexModel : PageModel
    {
        public List<Livro> Livros { get; set; } 

        public void OnGet() 
        {
            Livros = new List<Livro>(); 

            if (System.IO.File.Exists("livros.txt")) // Verifica se o arquivo existe 
            {
                var linhas = System.IO.File.ReadAllLines("livros.txt"); // Lê tudo 
                foreach (var linha in linhas) 
                {
                    var dados = linha.Split(';'); // Divide pelos delimitadores 
       
                var usuario = new Livro()
                    {
                        Id = int.Parse(dados[0]), 
                        titulo = dados[1],          
                        autor = dados[2],       
                        email = dados[3]          
                    };
                    Livros.Add(usuario); // Adiciona na coleção 
                }
            }
        }
    }
    
}
