using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CadastroUsuario.Models;
using System.Collections.Generic;
using System.Linq;

namespace CadastroUsuario.Pages.Livros
{
    public class DetalhesModel : PageModel
    {
        public Livro Livro { get; set; }

        public IActionResult OnGet(int id)
        {
            var livros = CarregarUsuarios();

            Livro = livos.FirstOrDefault(u => u.Id == id);

            if (Livro == null)
            {
                return RedirectToPage("/Livro/Index");
            }
            return Page();
        }

        private List<Usuario> CarregarUsuarios()
        {
            var Livros = new List<Usuario>();
            if (System.IO.File.Exists("livros.txt"))
            {
                var linhas = System.IO.File.ReadAllLines("livros.txt");
                foreach (var linha in linhas)
                {
                    var dados = linha.Split(';');
                    var usuario = new Usuario()
                    {
                        Id = int.Parse(dados[0]),
                        titulo = dados[1],
                        autor = dados[2],
                        isbn = dados[3]
                    };

                    Livros.Add(usuario);
                }
                
            }
            return Livros;
        }
       
    }
}
