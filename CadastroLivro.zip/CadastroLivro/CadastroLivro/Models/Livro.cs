using System.ComponentModel.DataAnnotations;

namespace CadastroUsuario.Models
{
    public class Livro
    {
        public int Id { get; set; }
        public string titulo { get; set; }
        public string autor { get; set; }
        public string isbn { get; set; }
    }
}
