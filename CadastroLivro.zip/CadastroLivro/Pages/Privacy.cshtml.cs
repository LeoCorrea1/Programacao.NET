﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CadastroLivro.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

