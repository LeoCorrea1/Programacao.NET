using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CadastroLivro.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {

    }
}
