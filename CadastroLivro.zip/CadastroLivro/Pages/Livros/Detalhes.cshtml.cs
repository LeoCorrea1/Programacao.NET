using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CadastroLivro.Models;
using System.Collections.Generic;
using System.Linq;

namespace CadastroLivro.Pages.Livros
{
    public class DetalhesModel : PageModel
    {
        public Livro Livro { get; set; }

        public IActionResult OnGet(int id)
        {
            var livros = CarregarLivros();

            Livro = livros.FirstOrDefault(u => u.Id == id);

            if (Livro == null)
            {
                return RedirectToPage("/Livros/Index");
            }
            return Page();
        }

        private List<Livro> CarregarLivros()
        {
            var livros = new List<Livro>();
            if (System.IO.File.Exists("livros.txt"))
            {
                var linhas = System.IO.File.ReadAllLines("livros.txt");
                foreach (var linha in linhas)
                {
                    var dados = linha.Split(';');
                    var livro = new Livro()
                    {
                        Id = int.Parse(dados[0]),
                        titulo = dados[1],
                        autor = dados[2],
                        isbn = dados[3]
                    };

                    livros.Add(livro);
                }
            }
            return livros;
        }
    }
}
