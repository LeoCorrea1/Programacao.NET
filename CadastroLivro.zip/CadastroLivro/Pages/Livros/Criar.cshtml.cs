using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CadastroLivro.Models;
using System.IO;

namespace CadastroLivro.Pages.Livros
{
    public class CriarModel : PageModel
    {
        [BindProperty]
        public Livro Livro { get; set; }
       
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            using (var writer = new StreamWriter("livros.txt", true))
            {
                writer.WriteLine(Livro.Id + ";" + Livro.titulo + ";" + Livro.autor + ";" + Livro.isbn);
            }
            return RedirectToPage("/livros/Index");
        }
    }
}
