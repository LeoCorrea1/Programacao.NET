using CadastroLivro.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.IO;

namespace CadastroLivro.Pages.Livros
{
    public class IndexModel : PageModel
    {
        public List<Livro> Livros { get; set; }

        public void OnGet()
        {
            Livros = new List<Livro>();

            if (System.IO.File.Exists("livros.txt"))
            {
                var linhas = System.IO.File.ReadAllLines("livros.txt");
                foreach (var linha in linhas)
                {
                    var dados = linha.Split(';');
                    var livro = new Livro()
                    {
                        Id = int.Parse(dados[0]),
                        titulo = dados[1],
                        autor = dados[2],
                        isbn = dados[3]
                    };
                    Livros.Add(livro);
                }
            }
        }
    }
}
