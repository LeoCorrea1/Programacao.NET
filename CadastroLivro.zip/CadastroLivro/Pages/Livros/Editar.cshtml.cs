using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CadastroLivro.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CadastroLivro.Pages.Livros
{
    public class EditarModel : PageModel
    {
        [BindProperty]
        public Livro Livro { get; set; }
        public void OnGet(int id)
        {
            var livros = CarregarLivros();
            Livro = livros.FirstOrDefault(u => u.Id == id); // Carrega dados atuais no formulário [cite: 892]
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page(); // Validação falhou [cite: 905]
            }

            // Lê todas as linhas do arquivo e converte para Lista manipulável [cite: 909]
            var linhas = System.IO.File.ReadAllLines("livros.txt").ToList();

            for (int i = 0; i < linhas.Count; i++)
            {
                var dados = linhas[i].Split(';');
                // Se encontrar a linha com o ID correspondente [cite: 918]
                if (int.Parse(dados[0]) == Livro.Id)
                {
                    // Substitui a linha com os novos dados digitados [cite: 923]
                    linhas[i] = Livro.Id + ";" + Livro.titulo + ";" + Livro.autor + ";" + Livro.isbn;
                    break;
                }
            }

            // Sobrescreve o arquivo texto inteiro com a lista de linhas atualizada [cite: 931]
            System.IO.File.WriteAllLines("livros.txt", contents: linhas);

            return RedirectToPage("/Livros/Index"); // Retorna à lista [cite: 932]
        }

        private List<Livro> CarregarLivros()
        {
            var lista = new List<Livro>();
            if (System.IO.File.Exists("livros.txt"))
            {
                var linhas = System.IO.File.ReadAllLines("livros.txt");
                foreach (var linha in linhas)
                {
                    var dados = linha.Split(';');
                    lista.Add(new Livro
                    {
                        Id = int.Parse(dados[0]),
                        titulo = dados[1],
                        autor = dados[2],
                        isbn = dados[3]
                    });
                }
            }
            return lista;
        }

    }
      

}
